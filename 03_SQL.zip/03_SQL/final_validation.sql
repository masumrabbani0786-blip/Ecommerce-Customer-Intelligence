-- Final data validation

SELECT
    COUNT(*) AS total_records,
    COUNT(DISTINCT order_id) AS total_orders,
    COUNT(DISTINCT customer_id) AS total_customers,
    COUNT(DISTINCT product_id) AS total_products
FROM ecommerce_sales;

-- Check for missing values in important columns

SELECT
    COUNT(*) FILTER (WHERE order_id IS NULL) AS missing_order_id,
    COUNT(*) FILTER (WHERE customer_id IS NULL) AS missing_customer_id,
    COUNT(*) FILTER (WHERE order_date IS NULL) AS missing_order_date,
    COUNT(*) FILTER (WHERE product_id IS NULL) AS missing_product_id,
    COUNT(*) FILTER (WHERE category IS NULL) AS missing_category,
    COUNT(*) FILTER (WHERE quantity IS NULL) AS missing_quantity,
    COUNT(*) FILTER (WHERE unit_price IS NULL) AS missing_unit_price,
    COUNT(*) FILTER (WHERE net_sales IS NULL) AS missing_net_sales
FROM ecommerce_sales;


-- Check for invalid sales values

SELECT
    COUNT(*) FILTER (WHERE quantity <= 0) AS invalid_quantity,
    COUNT(*) FILTER (WHERE unit_price < 0) AS negative_unit_price,
    COUNT(*) FILTER (WHERE discount_percentage < 0 OR discount_percentage > 100) AS invalid_discount,
    COUNT(*) FILTER (WHERE net_sales < 0) AS negative_net_sales
FROM ecommerce_sales;