/*
E-Commerce Customer Intelligence Project

Database: ecommerce_customer_intelligence
Table: ecommerce_sales

Main analysis:
customer sales, product/category performance,
revenue trends, discounts, RFM, churn and
some advanced SQL analysis.
*/


-- Basic numbers for the whole dataset

SELECT
    COUNT(DISTINCT customer_id) AS total_customers,
    COUNT(DISTINCT order_id) AS total_orders,
    SUM(quantity) AS total_items_sold,
    ROUND(SUM(gross_sales), 2) AS gross_revenue,
    ROUND(SUM(discount_amount), 2) AS total_discount,
    ROUND(SUM(net_sales), 2) AS net_revenue,
    ROUND(
        SUM(net_sales) / COUNT(DISTINCT order_id),
        2
    ) AS average_order_value
FROM ecommerce_sales;


-- Customer-wise sales and order activity

SELECT
    customer_id,
    COUNT(DISTINCT order_id) AS total_orders,
    SUM(quantity) AS total_items,
    ROUND(SUM(net_sales), 2) AS total_revenue,
    ROUND(
        SUM(net_sales) / COUNT(DISTINCT order_id),
        2
    ) AS average_order_value
FROM ecommerce_sales
GROUP BY customer_id
ORDER BY total_revenue DESC;


-- Top customers by total revenue

SELECT
    customer_id,
    COUNT(DISTINCT order_id) AS total_orders,
    SUM(quantity) AS total_items,
    ROUND(SUM(net_sales), 2) AS total_revenue
FROM ecommerce_sales
GROUP BY customer_id
ORDER BY total_revenue DESC
LIMIT 20;


-- Customers with the highest number of orders

SELECT
    customer_id,
    COUNT(DISTINCT order_id) AS purchase_frequency
FROM ecommerce_sales
GROUP BY customer_id
ORDER BY purchase_frequency DESC;


-- Category-wise performance

SELECT
    category,
    COUNT(DISTINCT order_id) AS total_orders,
    COUNT(DISTINCT product_id) AS unique_products,
    SUM(quantity) AS total_quantity,
    ROUND(SUM(net_sales), 2) AS net_revenue
FROM ecommerce_sales
GROUP BY category
ORDER BY net_revenue DESC;


-- Product-wise performance

SELECT
    product_id,
    product_name,
    category,
    SUM(quantity) AS total_quantity,
    COUNT(DISTINCT order_id) AS total_orders,
    ROUND(SUM(net_sales), 2) AS total_revenue
FROM ecommerce_sales
GROUP BY
    product_id,
    product_name,
    category
ORDER BY total_revenue DESC;


-- Best selling products by revenue

SELECT
    product_id,
    product_name,
    category,
    SUM(quantity) AS total_quantity,
    ROUND(SUM(net_sales), 2) AS total_revenue
FROM ecommerce_sales
GROUP BY
    product_id,
    product_name,
    category
ORDER BY total_revenue DESC
LIMIT 20;


-- Products with the highest quantity sold

SELECT
    product_id,
    product_name,
    category,
    SUM(quantity) AS total_quantity,
    ROUND(SUM(net_sales), 2) AS total_revenue
FROM ecommerce_sales
GROUP BY
    product_id,
    product_name,
    category
ORDER BY total_quantity DESC
LIMIT 20;


-- How much of the total revenue comes from each category

SELECT
    category,
    ROUND(SUM(net_sales), 2) AS category_revenue,
    ROUND(
        SUM(net_sales) * 100.0 /
        SUM(SUM(net_sales)) OVER (),
        2
    ) AS revenue_contribution_percentage
FROM ecommerce_sales
GROUP BY category
ORDER BY category_revenue DESC;


-- Monthly sales trend

SELECT
    DATE_TRUNC('month', order_date)::DATE AS month,
    COUNT(DISTINCT order_id) AS total_orders,
    SUM(quantity) AS total_quantity,
    ROUND(SUM(gross_sales), 2) AS gross_revenue,
    ROUND(SUM(discount_amount), 2) AS total_discount,
    ROUND(SUM(net_sales), 2) AS net_revenue,
    ROUND(
        SUM(net_sales) / COUNT(DISTINCT order_id),
        2
    ) AS average_order_value
FROM ecommerce_sales
GROUP BY DATE_TRUNC('month', order_date)
ORDER BY month;


-- Month-over-month revenue change

WITH monthly_sales AS (
    SELECT
        DATE_TRUNC('month', order_date)::DATE AS month,
        SUM(net_sales) AS revenue
    FROM ecommerce_sales
    GROUP BY DATE_TRUNC('month', order_date)
)

SELECT
    month,
    ROUND(revenue, 2) AS revenue,
    ROUND(
        (
            revenue -
            LAG(revenue) OVER (ORDER BY month)
        ) * 100.0 /
        NULLIF(LAG(revenue) OVER (ORDER BY month), 0),
        2
    ) AS mom_growth_percentage
FROM monthly_sales
ORDER BY month;


-- Year-wise performance

SELECT
    EXTRACT(YEAR FROM order_date)::INT AS year,
    COUNT(DISTINCT order_id) AS total_orders,
    SUM(quantity) AS total_quantity,
    ROUND(SUM(net_sales), 2) AS net_revenue,
    ROUND(
        SUM(net_sales) /
        COUNT(DISTINCT order_id),
        2
    ) AS average_order_value
FROM ecommerce_sales
GROUP BY EXTRACT(YEAR FROM order_date)
ORDER BY year;


-- Year-over-year revenue growth

WITH yearly_sales AS (
    SELECT
        EXTRACT(YEAR FROM order_date)::INT AS year,
        SUM(net_sales) AS revenue
    FROM ecommerce_sales
    GROUP BY EXTRACT(YEAR FROM order_date)
)

SELECT
    year,
    ROUND(revenue, 2) AS revenue,
    ROUND(
        (
            revenue -
            LAG(revenue) OVER (ORDER BY year)
        ) * 100.0 /
        NULLIF(LAG(revenue) OVER (ORDER BY year), 0),
        2
    ) AS yoy_growth_percentage
FROM yearly_sales
ORDER BY year;


-- Month with the highest revenue

SELECT
    DATE_TRUNC('month', order_date)::DATE AS month,
    ROUND(SUM(net_sales), 2) AS net_revenue
FROM ecommerce_sales
GROUP BY DATE_TRUNC('month', order_date)
ORDER BY net_revenue DESC
LIMIT 1;


-- Month with the lowest revenue

SELECT
    DATE_TRUNC('month', order_date)::DATE AS month,
    ROUND(SUM(net_sales), 2) AS net_revenue
FROM ecommerce_sales
GROUP BY DATE_TRUNC('month', order_date)
ORDER BY net_revenue ASC
LIMIT 1;


-- Overall discount and revenue picture

SELECT
    ROUND(SUM(gross_sales), 2) AS gross_revenue,
    ROUND(SUM(discount_amount), 2) AS total_discount,
    ROUND(SUM(net_sales), 2) AS net_revenue,
    ROUND(
        SUM(discount_amount) * 100.0 /
        NULLIF(SUM(gross_sales), 0),
        2
    ) AS overall_discount_percentage
FROM ecommerce_sales;


-- Comparing different discount ranges

SELECT
    CASE
        WHEN discount_percentage = 0 THEN 'No Discount'
        WHEN discount_percentage <= 10 THEN '0-10%'
        WHEN discount_percentage <= 20 THEN '11-20%'
        WHEN discount_percentage <= 30 THEN '21-30%'
        WHEN discount_percentage <= 40 THEN '31-40%'
        ELSE '40%+'
    END AS discount_range,
    COUNT(*) AS total_items,
    ROUND(SUM(gross_sales), 2) AS gross_revenue,
    ROUND(SUM(discount_amount), 2) AS total_discount,
    ROUND(SUM(net_sales), 2) AS net_revenue
FROM ecommerce_sales
GROUP BY
    CASE
        WHEN discount_percentage = 0 THEN 'No Discount'
        WHEN discount_percentage <= 10 THEN '0-10%'
        WHEN discount_percentage <= 20 THEN '11-20%'
        WHEN discount_percentage <= 30 THEN '21-30%'
        WHEN discount_percentage <= 40 THEN '31-40%'
        ELSE '40%+'
    END
ORDER BY net_revenue DESC;


-- Discount levels by category

SELECT
    category,
    ROUND(AVG(discount_percentage), 2) AS average_discount_percentage,
    ROUND(SUM(discount_amount), 2) AS total_discount,
    ROUND(SUM(gross_sales), 2) AS gross_revenue,
    ROUND(SUM(net_sales), 2) AS net_revenue
FROM ecommerce_sales
GROUP BY category
ORDER BY total_discount DESC;


-- Products where the average discount is quite high

SELECT
    product_id,
    product_name,
    category,
    ROUND(AVG(discount_percentage), 2) AS average_discount_percentage,
    ROUND(SUM(discount_amount), 2) AS total_discount,
    ROUND(SUM(net_sales), 2) AS net_revenue
FROM ecommerce_sales
GROUP BY
    product_id,
    product_name,
    category
HAVING AVG(discount_percentage) >= 30
ORDER BY total_discount DESC;


-- High discount products that are still generating good revenue

SELECT
    product_id,
    product_name,
    category,
    ROUND(AVG(discount_percentage), 2) AS average_discount_percentage,
    ROUND(SUM(net_sales), 2) AS net_revenue
FROM ecommerce_sales
GROUP BY
    product_id,
    product_name,
    category
HAVING
    AVG(discount_percentage) >= 20
    AND SUM(net_sales) >
        (
            SELECT AVG(product_revenue)
            FROM (
                SELECT
                    product_id,
                    SUM(net_sales) AS product_revenue
                FROM ecommerce_sales
                GROUP BY product_id
            ) AS product_sales
        )
ORDER BY net_revenue DESC;


-- RFM base table for customers

WITH customer_rfm AS (
    SELECT
        customer_id,
        MAX(order_date) AS last_order_date,
        COUNT(DISTINCT order_id) AS frequency,
        SUM(net_sales) AS monetary
    FROM ecommerce_sales
    GROUP BY customer_id
),

rfm_scores AS (
    SELECT
        customer_id,
        last_order_date,
        frequency,
        monetary,

        NTILE(5) OVER (
            ORDER BY last_order_date ASC
        ) AS recency_score,

        NTILE(5) OVER (
            ORDER BY frequency
        ) AS frequency_score,

        NTILE(5) OVER (
            ORDER BY monetary
        ) AS monetary_score

    FROM customer_rfm
)

SELECT
    customer_id,
    last_order_date,
    frequency,
    ROUND(monetary, 2) AS monetary,
    recency_score,
    frequency_score,
    monetary_score,

    CASE
        WHEN recency_score >= 4
             AND frequency_score >= 4
             AND monetary_score >= 4
            THEN 'Champions'

        WHEN frequency_score >= 4
             AND monetary_score >= 4
            THEN 'Loyal Customers'

        WHEN recency_score >= 4
             AND frequency_score >= 3
            THEN 'Potential Loyalists'

        WHEN recency_score <= 2
             AND monetary_score >= 3
            THEN 'At Risk'

        WHEN recency_score <= 2
             AND frequency_score <= 2
            THEN 'Lost Customers'

        ELSE 'Need Attention'
    END AS customer_segment

FROM rfm_scores
ORDER BY monetary DESC;


-- RFM segment distribution

WITH customer_rfm AS (
    SELECT
        customer_id,
        MAX(order_date) AS last_order_date,
        COUNT(DISTINCT order_id) AS frequency,
        SUM(net_sales) AS monetary
    FROM ecommerce_sales
    GROUP BY customer_id
),

rfm_scores AS (
    SELECT
        *,
        NTILE(5) OVER (ORDER BY last_order_date ASC) AS r_score,
        NTILE(5) OVER (ORDER BY frequency) AS f_score,
        NTILE(5) OVER (ORDER BY monetary) AS m_score
    FROM customer_rfm
),

segments AS (
    SELECT
        CASE
            WHEN r_score >= 4 AND f_score >= 4 AND m_score >= 4
                THEN 'Champions'
            WHEN f_score >= 4 AND m_score >= 4
                THEN 'Loyal Customers'
            WHEN r_score >= 4 AND f_score >= 3
                THEN 'Potential Loyalists'
            WHEN r_score <= 2 AND m_score >= 3
                THEN 'At Risk'
            WHEN r_score <= 2 AND f_score <= 2
                THEN 'Lost Customers'
            ELSE 'Need Attention'
        END AS customer_segment
    FROM rfm_scores
)

SELECT
    customer_segment,
    COUNT(*) AS total_customers,
    ROUND(
        COUNT(*) * 100.0 / SUM(COUNT(*)) OVER (),
        2
    ) AS customer_percentage
FROM segments
GROUP BY customer_segment
ORDER BY total_customers DESC;


-- Customer activity and inactivity status

WITH customer_activity AS (
    SELECT
        customer_id,
        MAX(order_date) AS last_order_date,
        COUNT(DISTINCT order_id) AS total_orders,
        SUM(net_sales) AS total_revenue
    FROM ecommerce_sales
    GROUP BY customer_id
)

SELECT
    customer_id,
    last_order_date,
    total_orders,
    ROUND(total_revenue, 2) AS total_revenue,
    CURRENT_DATE - last_order_date AS inactive_days,

    CASE
        WHEN CURRENT_DATE - last_order_date > 180
            THEN 'Churned'
        WHEN CURRENT_DATE - last_order_date > 90
            THEN 'At Risk'
        ELSE 'Active'
    END AS customer_status

FROM customer_activity
ORDER BY inactive_days DESC;


-- Churned, at-risk and active customer summary

WITH customer_activity AS (
    SELECT
        customer_id,
        MAX(order_date) AS last_order_date,
        SUM(net_sales) AS total_revenue
    FROM ecommerce_sales
    GROUP BY customer_id
),

customer_status AS (
    SELECT
        *,
        CASE
            WHEN CURRENT_DATE - last_order_date > 180
                THEN 'Churned'
            WHEN CURRENT_DATE - last_order_date > 90
                THEN 'At Risk'
            ELSE 'Active'
        END AS status
    FROM customer_activity
)

SELECT
    status,
    COUNT(*) AS total_customers,
    ROUND(SUM(total_revenue), 2) AS revenue
FROM customer_status
GROUP BY status
ORDER BY total_customers DESC;


-- High-value customers who have been inactive for a long time

WITH customer_activity AS (
    SELECT
        customer_id,
        MAX(order_date) AS last_order_date,
        COUNT(DISTINCT order_id) AS total_orders,
        SUM(net_sales) AS total_revenue
    FROM ecommerce_sales
    GROUP BY customer_id
)

SELECT
    customer_id,
    last_order_date,
    total_orders,
    ROUND(total_revenue, 2) AS total_revenue,
    CURRENT_DATE - last_order_date AS inactive_days
FROM customer_activity
WHERE CURRENT_DATE - last_order_date > 180
ORDER BY total_revenue DESC
LIMIT 100;


-- Revenue tied to customers inactive for more than 180 days

WITH customer_activity AS (
    SELECT
        customer_id,
        MAX(order_date) AS last_order_date,
        SUM(net_sales) AS total_revenue
    FROM ecommerce_sales
    GROUP BY customer_id
)

SELECT
    COUNT(*) AS churned_customers,
    ROUND(SUM(total_revenue), 2) AS revenue_at_risk
FROM customer_activity
WHERE CURRENT_DATE - last_order_date > 180;


-- Customers whose revenue is above the average customer revenue

WITH customer_revenue AS (
    SELECT
        customer_id,
        SUM(net_sales) AS total_revenue
    FROM ecommerce_sales
    GROUP BY customer_id
),

average_revenue AS (
    SELECT AVG(total_revenue) AS avg_customer_revenue
    FROM customer_revenue
)

SELECT
    cr.customer_id,
    ROUND(cr.total_revenue, 2) AS total_revenue
FROM customer_revenue cr
CROSS JOIN average_revenue ar
WHERE cr.total_revenue > ar.avg_customer_revenue
ORDER BY cr.total_revenue DESC;


-- Categories doing better than the average category

WITH category_revenue AS (
    SELECT
        category,
        SUM(net_sales) AS revenue
    FROM ecommerce_sales
    GROUP BY category
)

SELECT
    category,
    ROUND(revenue, 2) AS revenue
FROM category_revenue
WHERE revenue >
      (
          SELECT AVG(revenue)
          FROM category_revenue
      )
ORDER BY revenue DESC;


-- One-time customers vs repeat customers

WITH customer_orders AS (
    SELECT
        customer_id,
        COUNT(DISTINCT order_id) AS order_count
    FROM ecommerce_sales
    GROUP BY customer_id
)

SELECT
    CASE
        WHEN order_count = 1 THEN 'One-Time Customer'
        ELSE 'Repeat Customer'
    END AS customer_type,
    COUNT(*) AS total_customers,
    ROUND(
        COUNT(*) * 100.0 / SUM(COUNT(*)) OVER (),
        2
    ) AS customer_percentage
FROM customer_orders
GROUP BY
    CASE
        WHEN order_count = 1 THEN 'One-Time Customer'
        ELSE 'Repeat Customer'
    END;


-- Customers with revenue above the overall customer average

WITH customer_value AS (
    SELECT
        customer_id,
        COUNT(DISTINCT order_id) AS total_orders,
        SUM(net_sales) AS total_revenue
    FROM ecommerce_sales
    GROUP BY customer_id
)

SELECT
    customer_id,
    total_orders,
    ROUND(total_revenue, 2) AS total_revenue
FROM customer_value
WHERE total_revenue >
      (
          SELECT AVG(total_revenue)
          FROM customer_value
      )
ORDER BY total_revenue DESC;


-- Rank customers by revenue

SELECT
    customer_id,
    ROUND(SUM(net_sales), 2) AS total_revenue,
    RANK() OVER (
        ORDER BY SUM(net_sales) DESC
    ) AS revenue_rank
FROM ecommerce_sales
GROUP BY customer_id
ORDER BY revenue_rank;


-- Rank categories by revenue

SELECT
    category,
    ROUND(SUM(net_sales), 2) AS total_revenue,
    RANK() OVER (
        ORDER BY SUM(net_sales) DESC
    ) AS category_rank
FROM ecommerce_sales
GROUP BY category
ORDER BY category_rank;


-- Top 3 products inside every category

WITH product_revenue AS (
    SELECT
        category,
        product_id,
        product_name,
        SUM(net_sales) AS revenue
    FROM ecommerce_sales
    GROUP BY
        category,
        product_id,
        product_name
),

ranked_products AS (
    SELECT
        *,
        ROW_NUMBER() OVER (
            PARTITION BY category
            ORDER BY revenue DESC
        ) AS product_rank
    FROM product_revenue
)

SELECT
    category,
    product_id,
    product_name,
    ROUND(revenue, 2) AS revenue,
    product_rank
FROM ranked_products
WHERE product_rank <= 3
ORDER BY category, product_rank;


-- Running total of monthly revenue

WITH monthly_revenue AS (
    SELECT
        DATE_TRUNC('month', order_date)::DATE AS month,
        SUM(net_sales) AS revenue
    FROM ecommerce_sales
    GROUP BY DATE_TRUNC('month', order_date)
)

SELECT
    month,
    ROUND(revenue, 2) AS monthly_revenue,
    ROUND(
        SUM(revenue) OVER (
            ORDER BY month
            ROWS BETWEEN UNBOUNDED PRECEDING
            AND CURRENT ROW
        ),
        2
    ) AS cumulative_revenue
FROM monthly_revenue
ORDER BY month;


-- Current month compared with the previous month

WITH monthly_revenue AS (
    SELECT
        DATE_TRUNC('month', order_date)::DATE AS month,
        SUM(net_sales) AS revenue
    FROM ecommerce_sales
    GROUP BY DATE_TRUNC('month', order_date)
)

SELECT
    month,
    ROUND(revenue, 2) AS revenue,
    ROUND(
        LAG(revenue) OVER (ORDER BY month),
        2
    ) AS previous_month_revenue,
    ROUND(
        revenue -
        LAG(revenue) OVER (ORDER BY month),
        2
    ) AS revenue_change
FROM monthly_revenue
ORDER BY month;


-- Number each customer's orders in the order they were placed

SELECT
    customer_id,
    order_id,
    order_date,
    ROW_NUMBER() OVER (
        PARTITION BY customer_id
        ORDER BY order_date
    ) AS order_sequence
FROM (
    SELECT DISTINCT
        customer_id,
        order_id,
        order_date
    FROM ecommerce_sales
) AS orders
ORDER BY customer_id, order_date;


-- Overall repeat purchase rate

WITH customer_orders AS (
    SELECT
        customer_id,
        COUNT(DISTINCT order_id) AS total_orders
    FROM ecommerce_sales
    GROUP BY customer_id
)

SELECT
    COUNT(*) FILTER (
        WHERE total_orders = 1
    ) AS one_time_customers,

    COUNT(*) FILTER (
        WHERE total_orders > 1
    ) AS repeat_customers,

    ROUND(
        COUNT(*) FILTER (WHERE total_orders > 1) * 100.0 /
        COUNT(*),
        2
    ) AS repeat_customer_percentage
FROM customer_orders;


-- Final business check: top customers

SELECT
    customer_id,
    COUNT(DISTINCT order_id) AS total_orders,
    ROUND(SUM(net_sales), 2) AS total_revenue
FROM ecommerce_sales
GROUP BY customer_id
ORDER BY total_revenue DESC
LIMIT 20;


-- Final business check: best categories

SELECT
    category,
    ROUND(SUM(net_sales), 2) AS total_revenue
FROM ecommerce_sales
GROUP BY category
ORDER BY total_revenue DESC;


-- Final business check: best products

SELECT
    product_id,
    product_name,
    category,
    ROUND(SUM(net_sales), 2) AS total_revenue
FROM ecommerce_sales
GROUP BY
    product_id,
    product_name,
    category
ORDER BY total_revenue DESC
LIMIT 20;


-- Customers inactive for more than 90 days

SELECT
    customer_id,
    MAX(order_date) AS last_order_date,
    CURRENT_DATE - MAX(order_date) AS inactive_days,
    ROUND(SUM(net_sales), 2) AS total_revenue
FROM ecommerce_sales
GROUP BY customer_id
HAVING CURRENT_DATE - MAX(order_date) > 90
ORDER BY total_revenue DESC;


-- Revenue connected with customers inactive for more than 180 days

SELECT
    COUNT(DISTINCT customer_id) AS inactive_customers,
    ROUND(SUM(net_sales), 2) AS revenue_at_risk
FROM ecommerce_sales
WHERE customer_id IN (
    SELECT customer_id
    FROM ecommerce_sales
    GROUP BY customer_id
    HAVING CURRENT_DATE - MAX(order_date) > 180
);


-- Final discount summary

SELECT
    ROUND(SUM(gross_sales), 2) AS gross_revenue,
    ROUND(SUM(discount_amount), 2) AS total_discount,
    ROUND(SUM(net_sales), 2) AS net_revenue,
    ROUND(
        SUM(discount_amount) * 100.0 /
        NULLIF(SUM(gross_sales), 0),
        2
    ) AS discount_rate
FROM ecommerce_sales;


-- Repeat customer percentage

WITH customer_orders AS (
    SELECT
        customer_id,
        COUNT(DISTINCT order_id) AS order_count
    FROM ecommerce_sales
    GROUP BY customer_id
)

SELECT
    ROUND(
        COUNT(*) FILTER (
            WHERE order_count > 1
        ) * 100.0 / COUNT(*),
        2
    ) AS repeat_customer_percentage
FROM customer_orders;


-- Final revenue numbers

SELECT
    ROUND(SUM(gross_sales), 2) AS gross_revenue,
    ROUND(SUM(discount_amount), 2) AS total_discount,
    ROUND(SUM(net_sales), 2) AS net_revenue
FROM ecommerce_sales;