import pandas as pd

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    roc_auc_score,
    confusion_matrix
)

# Load the cleaned sales data
file_path = r"D:\Ecommerce_Customer_Intelligence\01_Raw_Data\ecommerce_data_sales_cleaned.csv"

df = pd.read_csv(file_path, encoding="utf-8-sig")

# Convert order date into datetime format
df["order_date"] = pd.to_datetime(df["order_date"])

# Use a historical cutoff so that future behavior can be used as the churn target
max_date = df["order_date"].max()
cutoff_date = max_date - pd.Timedelta(days=180)
future_end_date = cutoff_date + pd.Timedelta(days=180)

historical_data = df[df["order_date"] <= cutoff_date].copy()

future_data = df[
    (df["order_date"] > cutoff_date) &
    (df["order_date"] <= future_end_date)
].copy()

# Build customer features using only historical transactions
customer_features = (
    historical_data
    .groupby("customer_id")
    .agg(
        last_order_date=("order_date", "max"),
        first_order_date=("order_date", "min"),
        total_orders=("order_id", "nunique"),
        total_items=("quantity", "sum"),
        total_revenue=("net_sales", "sum"),
        average_order_value=("net_sales", "mean")
    )
    .reset_index()
)

# Calculate customer behavior before the cutoff date
customer_features["recency_days"] = (
    cutoff_date - customer_features["last_order_date"]
).dt.days

customer_features["customer_lifetime_days"] = (
    customer_features["last_order_date"]
    - customer_features["first_order_date"]
).dt.days

customer_features["purchase_frequency"] = (
    customer_features["total_orders"]
    / (customer_features["customer_lifetime_days"] + 1)
)

customer_features["purchase_frequency"] = (
    customer_features["purchase_frequency"].round(4)
)

# Identify customers who purchased during the following 180 days
future_customers = set(
    future_data["customer_id"].unique()
)

# A customer is considered churned if they did not purchase in the next 180 days
customer_features["churn"] = (
    ~customer_features["customer_id"].isin(future_customers)
).astype(int)

# Prepare the model features
features = [
    "recency_days",
    "total_orders",
    "total_items",
    "total_revenue",
    "average_order_value",
    "customer_lifetime_days",
    "purchase_frequency"
]

X = customer_features[features]
y = customer_features["churn"]

# Split the historical customer data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.20,
    random_state=42,
    stratify=y
)

# Scale numerical features
scaler = StandardScaler()

X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# Train the churn prediction model
model = LogisticRegression(
    max_iter=1000,
    random_state=42
)

model.fit(X_train_scaled, y_train)

# Generate predictions on the test data
y_pred = model.predict(X_test_scaled)
y_probability = model.predict_proba(X_test_scaled)[:, 1]

# Calculate model performance
accuracy = accuracy_score(y_test, y_pred)
precision = precision_score(y_test, y_pred, zero_division=0)
recall = recall_score(y_test, y_pred, zero_division=0)
f1 = f1_score(y_test, y_pred, zero_division=0)
roc_auc = roc_auc_score(y_test, y_probability)

print("\nModel Performance")
print("-----------------")
print("Accuracy :", round(accuracy, 4))
print("Precision:", round(precision, 4))
print("Recall   :", round(recall, 4))
print("F1 Score :", round(f1, 4))
print("ROC-AUC  :", round(roc_auc, 4))

print("\nConfusion Matrix")
print(confusion_matrix(y_test, y_pred))

# Create predictions for the historical customer dataset
customer_features["churn_probability"] = (
    model.predict_proba(
        scaler.transform(customer_features[features])
    )[:, 1] * 100
)

customer_features["churn_probability"] = (
    customer_features["churn_probability"].round(2)
)

# Assign customers to risk groups
customer_features["risk_level"] = pd.cut(
    customer_features["churn_probability"],
    bins=[-0.01, 30, 60, 100],
    labels=[
        "Low Risk",
        "Medium Risk",
        "High Risk"
    ]
)

# Sort customers from highest to lowest churn probability
customer_features = customer_features.sort_values(
    by="churn_probability",
    ascending=False
)

# Save historical model predictions
customer_features.to_csv(
    r"D:\Ecommerce_Customer_Intelligence\01_Raw_Data\historical_churn_predictions.csv",
    index=False
)

# Create a summary of the model's risk groups
risk_summary = (
    customer_features
    .groupby("risk_level", observed=True)
    .agg(
        customers=("customer_id", "nunique"),
        total_revenue=("total_revenue", "sum"),
        average_revenue=("total_revenue", "mean"),
        average_orders=("total_orders", "mean"),
        average_churn_probability=("churn_probability", "mean")
    )
    .reset_index()
)

risk_summary["customer_percentage"] = (
    risk_summary["customers"]
    / risk_summary["customers"].sum()
) * 100

risk_summary = risk_summary.round(2)

risk_summary.to_csv(
    r"D:\Ecommerce_Customer_Intelligence\01_Raw_Data\historical_churn_risk_summary.csv",
    index=False
)

# Score current customers using their latest available behavior
current_features = (
    df.groupby("customer_id")
    .agg(
        last_order_date=("order_date", "max"),
        first_order_date=("order_date", "min"),
        total_orders=("order_id", "nunique"),
        total_items=("quantity", "sum"),
        total_revenue=("net_sales", "sum"),
        average_order_value=("net_sales", "mean")
    )
    .reset_index()
)

current_features["recency_days"] = (
    max_date - current_features["last_order_date"]
).dt.days

current_features["customer_lifetime_days"] = (
    current_features["last_order_date"]
    - current_features["first_order_date"]
).dt.days

current_features["purchase_frequency"] = (
    current_features["total_orders"]
    / (current_features["customer_lifetime_days"] + 1)
)

current_features["purchase_frequency"] = (
    current_features["purchase_frequency"].round(4)
)

# Predict current customer churn risk
current_features["churn_probability"] = (
    model.predict_proba(
        scaler.transform(current_features[features])
    )[:, 1] * 100
)

current_features["churn_probability"] = (
    current_features["churn_probability"].round(2)
)

current_features["risk_level"] = pd.cut(
    current_features["churn_probability"],
    bins=[-0.01, 30, 60, 100],
    labels=[
        "Low Risk",
        "Medium Risk",
        "High Risk"
    ]
)

current_features = current_features.sort_values(
    by="churn_probability",
    ascending=False
)

# Save current customer risk predictions
current_features.to_csv(
    r"D:\Ecommerce_Customer_Intelligence\01_Raw_Data\current_customer_churn_risk.csv",
    index=False
)

# Save the highest-risk customers
high_risk_customers = current_features[
    current_features["risk_level"] == "High Risk"
].copy()

high_risk_customers.to_csv(
    r"D:\Ecommerce_Customer_Intelligence\01_Raw_Data\current_high_risk_customers.csv",
    index=False
)

print("\nHistorical Churn Summary")
print(customer_features["churn"].value_counts())

print("\nRisk Summary")
print(risk_summary)

print("\nHigh-Risk Current Customers:",
      len(high_risk_customers))

print("\nTop High-Risk Customers")
print(
    high_risk_customers[
        [
            "customer_id",
            "recency_days",
            "total_orders",
            "total_revenue",
            "churn_probability",
            "risk_level"
        ]
    ].head(10)
)

print("\nAnalysis completed successfully.")