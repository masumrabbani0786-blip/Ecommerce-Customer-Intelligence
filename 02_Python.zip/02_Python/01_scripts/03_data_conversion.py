import pandas as pd

# Load cleaned dataset
file_path = r"D:\Ecommerce_Customer_Intelligence\01_Raw_Data\ecommerce_data_cleaned.csv"

df = pd.read_csv(file_path, encoding="utf-8-sig")

print("=" * 60)
print("DATE CONVERSION & VALIDATION")
print("=" * 60)

# Check original data type
print("\nBefore conversion:")
print(df["order_date"].dtype)

# Convert order_date to datetime
df["order_date"] = pd.to_datetime(
    df["order_date"],
    errors="coerce"
)

# Check data type after conversion
print("\nAfter conversion:")
print(df["order_date"].dtype)

# Check invalid dates
invalid_dates = df["order_date"].isna().sum()

print("\nInvalid dates:", invalid_dates)

# Date range
print("\nMinimum Order Date:", df["order_date"].min())
print("Maximum Order Date:", df["order_date"].max())

# Save date-cleaned dataset
output_path = r"D:\Ecommerce_Customer_Intelligence\01_Raw_Data\ecommerce_data_date_cleaned.csv"

df.to_csv(
    output_path,
    index=False,
    encoding="utf-8-sig"
)

print("\nDate-cleaned dataset saved successfully.")
print("Rows:", len(df))
print("Columns:", len(df.columns))