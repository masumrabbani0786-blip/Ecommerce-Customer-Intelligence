import pandas as pd

# Load the cleaned sales data
file_path = r"D:\Ecommerce_Customer_Intelligence\01_Raw_Data\ecommerce_data_sales_cleaned.csv"

df = pd.read_csv(file_path, encoding="utf-8-sig")

# Convert order date into datetime format
df["order_date"] = pd.to_datetime(df["order_date"])

# Use the latest order date as the analysis reference date
reference_date = df["order_date"].max()

# Create customer-level features
customer_data = (
    df.groupby("customer_id")
    .agg(
        first_order_date=("order_date", "min"),
        last_order_date=("order_date", "max"),
        total_orders=("order_id", "nunique"),
        total_items=("quantity", "sum"),
        total_revenue=("net_sales", "sum"),
        average_order_value=("net_sales", "mean")
    )
    .reset_index()
)

# Calculate customer recency
customer_data["recency_days"] = (
    reference_date - customer_data["last_order_date"]
).dt.days

# Calculate customer lifetime
customer_data["customer_lifetime_days"] = (
    customer_data["last_order_date"]
    - customer_data["first_order_date"]
).dt.days

# Calculate purchase frequency
customer_data["purchase_frequency"] = (
    customer_data["total_orders"]
    / (customer_data["customer_lifetime_days"] + 1)
)

customer_data["purchase_frequency"] = (
    customer_data["purchase_frequency"].round(4)
)

# Identify repeat and one-time customers
customer_data["customer_type"] = customer_data["total_orders"].apply(
    lambda x: "Repeat Customer"
    if x > 1
    else "One-Time Customer"
)

# Define churn based on customer inactivity
churn_threshold = 180

customer_data["churn"] = (
    customer_data["recency_days"] > churn_threshold
).astype(int)

# Add a readable churn status
customer_data["churn_status"] = customer_data["churn"].map({
    0: "Active",
    1: "Churned"
})

# Create revenue segments
customer_data["revenue_segment"] = pd.qcut(
    customer_data["total_revenue"],
    q=4,
    labels=[
        "Low Value",
        "Medium Value",
        "High Value",
        "Very High Value"
    ],
    duplicates="drop"
)

# Round numerical values
customer_data["total_revenue"] = customer_data["total_revenue"].round(2)
customer_data["average_order_value"] = customer_data["average_order_value"].round(2)

# Save the customer churn dataset
output_path = r"D:\Ecommerce_Customer_Intelligence\01_Raw_Data\customer_churn_features.csv"

customer_data.to_csv(
    output_path,
    index=False
)

# Create churn summary
churn_summary = (
    customer_data
    .groupby("churn_status")
    .agg(
        customers=("customer_id", "nunique"),
        total_revenue=("total_revenue", "sum"),
        average_revenue=("total_revenue", "mean"),
        average_orders=("total_orders", "mean"),
        average_recency=("recency_days", "mean")
    )
    .reset_index()
)

churn_summary["customer_percentage"] = (
    churn_summary["customers"]
    / churn_summary["customers"].sum()
) * 100

churn_summary["customer_percentage"] = (
    churn_summary["customer_percentage"].round(2)
)

churn_summary["total_revenue"] = (
    churn_summary["total_revenue"].round(2)
)

churn_summary["average_revenue"] = (
    churn_summary["average_revenue"].round(2)
)

churn_summary["average_orders"] = (
    churn_summary["average_orders"].round(2)
)

churn_summary["average_recency"] = (
    churn_summary["average_recency"].round(2)
)

# Save churn summary
churn_summary.to_csv(
    r"D:\Ecommerce_Customer_Intelligence\01_Raw_Data\churn_summary.csv",
    index=False
)

# Display the results
print("\nReference Date:", reference_date.date())

print("\nChurn Threshold:", churn_threshold, "days")

print("\nCustomer Churn Summary:")
print(churn_summary)

print("\nChurned Customers:",
      customer_data["churn"].sum())

print("\nActive Customers:",
      (customer_data["churn"] == 0).sum())

print("\nChurn Rate:",
      round(customer_data["churn"].mean() * 100, 2),
      "%")

print("\nCustomer Churn Features:")
print(customer_data.head(10))

print("\nAnalysis completed successfully.")