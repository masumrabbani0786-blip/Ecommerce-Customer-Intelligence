import pandas as pd

# Load raw dataset
file_path = r"D:\Ecommerce_Customer_Intelligence\01_Raw_Data\ecommerce_data_90000.csv"

df = pd.read_csv(file_path, encoding="latin1")

print("=" * 60)
print("DUPLICATE REMOVAL")
print("=" * 60)

# Check duplicates before removal
duplicate_count = df.duplicated().sum()

print("Duplicate rows before cleaning:", duplicate_count)
print("Rows before cleaning:", len(df))

# Remove exact duplicate rows
df_cleaned = df.drop_duplicates().copy()

print("\nDuplicate rows after cleaning:", df_cleaned.duplicated().sum())
print("Rows after cleaning:", len(df_cleaned))
print("Rows removed:", len(df) - len(df_cleaned))

# Save cleaned dataset
output_path = r"D:\Ecommerce_Customer_Intelligence\01_Raw_Data\ecommerce_data_cleaned.csv"

df_cleaned.to_csv(output_path, index=False, encoding="utf-8-sig")

print("\nCleaned dataset saved successfully.")
print("File:", output_path)