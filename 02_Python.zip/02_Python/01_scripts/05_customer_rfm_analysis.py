import pandas as pd

# Load sales-cleaned dataset
file_path = r"D:\Ecommerce_Customer_Intelligence\01_Raw_Data\ecommerce_data_sales_cleaned.csv"

df = pd.read_csv(file_path, encoding="utf-8-sig")

# Convert date
df["order_date"] = pd.to_datetime(df["order_date"], errors="coerce")

print("=" * 70)
print("CUSTOMER INTELLIGENCE & RFM ANALYSIS")
print("=" * 70)

# Reference date = one day after the last order
reference_date = df["order_date"].max() + pd.Timedelta(days=1)

print("\nReference Date:", reference_date.date())

# Customer-level aggregation
customer_rfm = df.groupby("customer_id").agg(
    last_order_date=("order_date", "max"),
    first_order_date=("order_date", "min"),
    frequency=("order_id", "nunique"),
    monetary=("net_sales", "sum"),
    total_items=("quantity", "sum")
).reset_index()

# Recency
customer_rfm["recency"] = (
    reference_date - customer_rfm["last_order_date"]
).dt.days

# Average Order Value
customer_rfm["average_order_value"] = (
    customer_rfm["monetary"] /
    customer_rfm["frequency"]
)

# Customer lifetime in days
customer_rfm["customer_lifetime_days"] = (
    customer_rfm["last_order_date"] -
    customer_rfm["first_order_date"]
).dt.days

# Round monetary metrics
customer_rfm["monetary"] = customer_rfm["monetary"].round(2)
customer_rfm["average_order_value"] = (
    customer_rfm["average_order_value"].round(2)
)

print("\nCUSTOMER DATASET OVERVIEW")
print("Customers:", len(customer_rfm))
print("Columns:", len(customer_rfm.columns))

print("\nFirst 10 Customers:")
print(customer_rfm.head(10))

print("\nRFM SUMMARY:")
print(customer_rfm[
    [
        "recency",
        "frequency",
        "monetary",
        "average_order_value"
    ]
].describe())

# Save customer-level dataset
output_path = r"D:\Ecommerce_Customer_Intelligence\01_Raw_Data\customer_rfm_data.csv"

customer_rfm.to_csv(
    output_path,
    index=False,
    encoding="utf-8-sig"
)

print("\nCustomer RFM dataset saved successfully.")
print("File:", output_path)