import pandas as pd

# Load customer RFM dataset
file_path = r"D:\Ecommerce_Customer_Intelligence\01_Raw_Data\customer_rfm_data.csv"

df = pd.read_csv(file_path, encoding="utf-8-sig")

print("=" * 70)
print("RFM SCORING & CUSTOMER SEGMENTATION")
print("=" * 70)

# RFM Scores
# Recency: lower is better
df["R_score"] = pd.qcut(
    df["recency"].rank(method="first"),
    5,
    labels=[5, 4, 3, 2, 1]
).astype(int)

# Frequency: higher is better
df["F_score"] = pd.qcut(
    df["frequency"].rank(method="first"),
    5,
    labels=[1, 2, 3, 4, 5]
).astype(int)

# Monetary: higher is better
df["M_score"] = pd.qcut(
    df["monetary"].rank(method="first"),
    5,
    labels=[1, 2, 3, 4, 5]
).astype(int)

# Overall RFM Score
df["RFM_score"] = (
    df["R_score"] +
    df["F_score"] +
    df["M_score"]
)

# Customer Segmentation
def assign_segment(row):

    r = row["R_score"]
    f = row["F_score"]
    m = row["M_score"]

    if r >= 4 and f >= 4 and m >= 4:
        return "Champions"

    elif r >= 3 and f >= 4:
        return "Loyal Customers"

    elif r >= 4 and f >= 2:
        return "Potential Loyalists"

    elif r <= 2 and f >= 3:
        return "At Risk"

    elif r <= 2 and f <= 2:
        return "Lost Customers"

    else:
        return "Need Attention"


df["customer_segment"] = df.apply(
    assign_segment,
    axis=1
)

# Segment summary
segment_summary = df.groupby("customer_segment").agg(
    customers=("customer_id", "count"),
    total_revenue=("monetary", "sum"),
    average_revenue=("monetary", "mean"),
    average_orders=("frequency", "mean"),
    average_recency=("recency", "mean")
).reset_index()

segment_summary["total_revenue"] = (
    segment_summary["total_revenue"].round(2)
)

segment_summary["average_revenue"] = (
    segment_summary["average_revenue"].round(2)
)

segment_summary["average_orders"] = (
    segment_summary["average_orders"].round(2)
)

segment_summary["average_recency"] = (
    segment_summary["average_recency"].round(2)
)

print("\nCUSTOMER SEGMENTS")
print(segment_summary)

print("\nTOTAL CUSTOMERS:", len(df))

# Save customer segmentation dataset
output_path = r"D:\Ecommerce_Customer_Intelligence\01_Raw_Data\customer_rfm_segmented.csv"

df.to_csv(
    output_path,
    index=False,
    encoding="utf-8-sig"
)

# Save segment summary
summary_path = r"D:\Ecommerce_Customer_Intelligence\01_Raw_Data\customer_segment_summary.csv"

segment_summary.to_csv(
    summary_path,
    index=False,
    encoding="utf-8-sig"
)

print("\nRFM segmented dataset saved successfully.")
print("Customer file:", output_path)
print("Segment summary:", summary_path)