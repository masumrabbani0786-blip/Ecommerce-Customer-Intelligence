import pandas as pd

# Load dataset
file_path = r"D:\Ecommerce_Customer_Intelligence\01_Raw_Data\ecommerce_data_90000.csv"

df = pd.read_csv(file_path, encoding="latin1")

print("=" * 70)
print("E-COMMERCE DATA QUALITY AUDIT")
print("=" * 70)

# 1. Dataset size
print("\n1. DATASET SIZE")
print("Rows:", df.shape[0])
print("Columns:", df.shape[1])

# 2. Column names
print("\n2. COLUMN NAMES")
for i, col in enumerate(df.columns, 1):
    print(i, "->", col)

# 3. Data types
print("\n3. DATA TYPES")
print(df.dtypes)

# 4. Missing values
print("\n4. MISSING VALUES")
missing = df.isnull().sum()
missing_percent = (missing / len(df)) * 100

missing_report = pd.DataFrame({
    "Missing_Count": missing,
    "Missing_Percentage": missing_percent.round(2)
})

print(missing_report)

# 5. Duplicate rows
print("\n5. DUPLICATE ROWS")
print("Duplicate rows:", df.duplicated().sum())

# 6. Unique values
print("\n6. UNIQUE VALUES")
print(df.nunique())

# 7. Numerical summary
print("\n7. NUMERICAL SUMMARY")
print(df.describe())

print("\n" + "=" * 70)
print("DATA QUALITY AUDIT COMPLETED")
print("=" * 70)