import pandas as pd

# Load segmented customer dataset
file_path = r"D:\Ecommerce_Customer_Intelligence\01_Raw_Data\customer_rfm_segmented.csv"

df = pd.read_csv(file_path, encoding="utf-8-sig")

print("=" * 70)
print("CUSTOMER SEGMENT VALIDATION")
print("=" * 70)

# Segment count
segment_count = (
    df["customer_segment"]
    .value_counts()
    .reset_index()
)

segment_count.columns = [
    "customer_segment",
    "customers"
]

# Customer percentage
segment_count["customer_percentage"] = (
    segment_count["customers"] /
    len(df) * 100
).round(2)

print("\nCUSTOMER SEGMENT DISTRIBUTION")
print(segment_count)

# Revenue by segment
revenue_summary = df.groupby("customer_segment").agg(
    customers=("customer_id", "count"),
    total_revenue=("monetary", "sum"),
    average_revenue=("monetary", "mean"),
    average_orders=("frequency", "mean"),
    average_recency=("recency", "mean")
).reset_index()

revenue_summary["total_revenue"] = (
    revenue_summary["total_revenue"].round(2)
)

revenue_summary["average_revenue"] = (
    revenue_summary["average_revenue"].round(2)
)

revenue_summary["average_orders"] = (
    revenue_summary["average_orders"].round(2)
)

revenue_summary["average_recency"] = (
    revenue_summary["average_recency"].round(2)
)

print("\nSEGMENT PERFORMANCE")
print(revenue_summary)

# Validation
print("\nVALIDATION")
print("Total customers:", len(df))
print("Total segmented customers:", segment_count["customers"].sum())
print(
    "Unsegmented customers:",
    len(df) - segment_count["customers"].sum()
)

# Save validation files
segment_count.to_csv(
    r"D:\Ecommerce_Customer_Intelligence\01_Raw_Data\segment_distribution.csv",
    index=False,
    encoding="utf-8-sig"
)

revenue_summary.to_csv(
    r"D:\Ecommerce_Customer_Intelligence\01_Raw_Data\segment_performance.csv",
    index=False,
    encoding="utf-8-sig"
)

print("\nValidation files saved successfully.")