import pandas as pd

# Load sales-cleaned dataset
file_path = r"D:\Ecommerce_Customer_Intelligence\01_Raw_Data\ecommerce_data_sales_cleaned.csv"

df = pd.read_csv(file_path, encoding="utf-8-sig")

print("=" * 70)
print("PRODUCT & CATEGORY INTELLIGENCE")
print("=" * 70)

# --------------------------------------------------
# 1. CATEGORY ANALYSIS
# --------------------------------------------------

category_summary = df.groupby("category").agg(
    orders=("order_id", "nunique"),
    quantity_sold=("quantity", "sum"),
    gross_sales=("gross_sales", "sum"),
    discount_amount=("discount_amount", "sum"),
    net_sales=("net_sales", "sum")
).reset_index()

category_summary["average_order_value"] = (
    category_summary["net_sales"] /
    category_summary["orders"]
).round(2)

category_summary = category_summary.round(2)

# Sort by revenue
category_summary = category_summary.sort_values(
    "net_sales",
    ascending=False
)

print("\nCATEGORY PERFORMANCE")
print(category_summary)

# --------------------------------------------------
# 2. TOP PRODUCTS BY REVENUE
# --------------------------------------------------

product_summary = df.groupby(
    ["product_id", "product_name", "category"]
).agg(
    orders=("order_id", "nunique"),
    quantity_sold=("quantity", "sum"),
    net_sales=("net_sales", "sum")
).reset_index()

product_summary = product_summary.round(2)

top_products_revenue = product_summary.sort_values(
    "net_sales",
    ascending=False
).head(20)

print("\nTOP 20 PRODUCTS BY REVENUE")
print(top_products_revenue)

# --------------------------------------------------
# 3. TOP PRODUCTS BY QUANTITY
# --------------------------------------------------

top_products_quantity = product_summary.sort_values(
    "quantity_sold",
    ascending=False
).head(20)

print("\nTOP 20 PRODUCTS BY QUANTITY")
print(top_products_quantity)

# --------------------------------------------------
# 4. PRODUCT SUMMARY
# --------------------------------------------------

print("\nPRODUCT OVERVIEW")
print("Unique Products:", df["product_id"].nunique())
print("Categories:", df["category"].nunique())

# --------------------------------------------------
# 5. SAVE FILES
# --------------------------------------------------

category_path = r"D:\Ecommerce_Customer_Intelligence\01_Raw_Data\category_performance.csv"

product_path = r"D:\Ecommerce_Customer_Intelligence\01_Raw_Data\product_performance.csv"

top_revenue_path = r"D:\Ecommerce_Customer_Intelligence\01_Raw_Data\top_products_revenue.csv"

top_quantity_path = r"D:\Ecommerce_Customer_Intelligence\01_Raw_Data\top_products_quantity.csv"

category_summary.to_csv(
    category_path,
    index=False,
    encoding="utf-8-sig"
)

product_summary.to_csv(
    product_path,
    index=False,
    encoding="utf-8-sig"
)

top_products_revenue.to_csv(
    top_revenue_path,
    index=False,
    encoding="utf-8-sig"
)

top_products_quantity.to_csv(
    top_quantity_path,
    index=False,
    encoding="utf-8-sig"
)

print("\nAll product and category analysis files saved successfully.")