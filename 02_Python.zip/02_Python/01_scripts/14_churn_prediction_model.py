import pandas as pd

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    roc_auc_score,
    confusion_matrix
)

# Load customer churn features
file_path = r"D:\Ecommerce_Customer_Intelligence\01_Raw_Data\customer_churn_features.csv"

df = pd.read_csv(file_path, encoding="utf-8-sig")

# Select the features used for prediction
features = [
    "recency_days",
    "total_orders",
    "total_items",
    "total_revenue",
    "average_order_value",
    "customer_lifetime_days",
    "purchase_frequency"
]

X = df[features]
y = df["churn"]

# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.20,
    random_state=42,
    stratify=y
)

# Scale numerical features
scaler = StandardScaler()

X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# Train the logistic regression model
model = LogisticRegression(
    max_iter=1000,
    random_state=42
)

model.fit(X_train_scaled, y_train)

# Generate predictions
y_pred = model.predict(X_test_scaled)
y_probability = model.predict_proba(X_test_scaled)[:, 1]

# Calculate model performance
accuracy = accuracy_score(y_test, y_pred)
precision = precision_score(y_test, y_pred, zero_division=0)
recall = recall_score(y_test, y_pred, zero_division=0)
f1 = f1_score(y_test, y_pred, zero_division=0)
roc_auc = roc_auc_score(y_test, y_probability)

# Display model performance
print("\nModel Performance")
print("-----------------")
print("Accuracy :", round(accuracy, 4))
print("Precision:", round(precision, 4))
print("Recall   :", round(recall, 4))
print("F1 Score :", round(f1, 4))
print("ROC-AUC  :", round(roc_auc, 4))

# Display confusion matrix
print("\nConfusion Matrix")
print(confusion_matrix(y_test, y_pred))

# Predict churn probability for all customers
all_scaled = scaler.transform(X)

df["churn_probability"] = model.predict_proba(all_scaled)[:, 1]

df["churn_probability"] = (
    df["churn_probability"] * 100
).round(2)

# Create risk categories
df["risk_level"] = pd.cut(
    df["churn_probability"],
    bins=[-0.01, 30, 60, 100],
    labels=[
        "Low Risk",
        "Medium Risk",
        "High Risk"
    ]
)

# Sort customers by churn probability
df = df.sort_values(
    by="churn_probability",
    ascending=False
)

# Save predictions for all customers
df.to_csv(
    r"D:\Ecommerce_Customer_Intelligence\01_Raw_Data\customer_churn_predictions.csv",
    index=False
)

# Create a high-risk customer list
high_risk_customers = df[
    df["risk_level"] == "High Risk"
].copy()

high_risk_customers.to_csv(
    r"D:\Ecommerce_Customer_Intelligence\01_Raw_Data\high_risk_customers.csv",
    index=False
)

# Create risk summary
risk_summary = (
    df.groupby("risk_level", observed=True)
    .agg(
        customers=("customer_id", "nunique"),
        total_revenue=("total_revenue", "sum"),
        average_revenue=("total_revenue", "mean"),
        average_orders=("total_orders", "mean"),
        average_churn_probability=("churn_probability", "mean")
    )
    .reset_index()
)

risk_summary["customer_percentage"] = (
    risk_summary["customers"]
    / risk_summary["customers"].sum()
) * 100

risk_summary["customer_percentage"] = (
    risk_summary["customer_percentage"].round(2)
)

risk_summary["total_revenue"] = (
    risk_summary["total_revenue"].round(2)
)

risk_summary["average_revenue"] = (
    risk_summary["average_revenue"].round(2)
)

risk_summary["average_orders"] = (
    risk_summary["average_orders"].round(2)
)

risk_summary["average_churn_probability"] = (
    risk_summary["average_churn_probability"].round(2)
)

risk_summary.to_csv(
    r"D:\Ecommerce_Customer_Intelligence\01_Raw_Data\churn_risk_summary.csv",
    index=False
)

# Display risk summary
print("\nChurn Risk Summary")
print(risk_summary)

print("\nHigh-Risk Customers:",
      len(high_risk_customers))

print("\nTop High-Risk Customers")
print(
    high_risk_customers[
        [
            "customer_id",
            "recency_days",
            "total_orders",
            "total_revenue",
            "churn_probability",
            "risk_level"
        ]
    ].head(10)
)

print("\nAnalysis completed successfully.")