import pandas as pd

# Load the cleaned sales data
file_path = r"D:\Ecommerce_Customer_Intelligence\01_Raw_Data\ecommerce_data_sales_cleaned.csv"

df = pd.read_csv(file_path, encoding="utf-8-sig")

# Create discount ranges
df["discount_range"] = pd.cut(
    df["discount_percentage"],
    bins=[-0.01, 5, 10, 20, 30, 50, 100],
    labels=[
        "0-5%",
        "5-10%",
        "10-20%",
        "20-30%",
        "30-50%",
        "50%+"
    ]
)

# Calculate overall discount and revenue metrics
overall_metrics = pd.DataFrame({
    "metric": [
        "Total Gross Sales",
        "Total Discount Amount",
        "Total Net Sales",
        "Average Discount Percentage",
        "Total Orders"
    ],
    "value": [
        df["gross_sales"].sum(),
        df["discount_amount"].sum(),
        df["net_sales"].sum(),
        df["discount_percentage"].mean(),
        df["order_id"].nunique()
    ]
})

overall_metrics["value"] = overall_metrics["value"].round(2)

# Analyze performance by discount range
discount_analysis = (
    df.groupby("discount_range", observed=True)
    .agg(
        orders=("order_id", "nunique"),
        quantity=("quantity", "sum"),
        gross_sales=("gross_sales", "sum"),
        discount_amount=("discount_amount", "sum"),
        net_sales=("net_sales", "sum")
    )
    .reset_index()
)

discount_analysis["average_order_value"] = (
    discount_analysis["net_sales"]
    / discount_analysis["orders"]
)

discount_analysis["discount_percentage_of_gross"] = (
    discount_analysis["discount_amount"]
    / discount_analysis["gross_sales"]
) * 100

discount_analysis = discount_analysis.round(2)

# Analyze discount performance by category
category_discount = (
    df.groupby("category", observed=True)
    .agg(
        orders=("order_id", "nunique"),
        quantity=("quantity", "sum"),
        gross_sales=("gross_sales", "sum"),
        discount_amount=("discount_amount", "sum"),
        net_sales=("net_sales", "sum"),
        average_discount=("discount_percentage", "mean")
    )
    .reset_index()
)

category_discount["discount_impact"] = (
    category_discount["discount_amount"]
    / category_discount["gross_sales"]
) * 100

category_discount = category_discount.round(2)

# Identify products receiving the highest discounts
product_discount = (
    df.groupby(
        ["product_id", "product_name", "category"],
        observed=True
    )
    .agg(
        orders=("order_id", "nunique"),
        quantity=("quantity", "sum"),
        gross_sales=("gross_sales", "sum"),
        discount_amount=("discount_amount", "sum"),
        net_sales=("net_sales", "sum"),
        average_discount=("discount_percentage", "mean")
    )
    .reset_index()
)

product_discount["discount_impact"] = (
    product_discount["discount_amount"]
    / product_discount["gross_sales"]
) * 100

product_discount = product_discount.round(2)

# Sort products by discount percentage
high_discount_products = product_discount.sort_values(
    by="average_discount",
    ascending=False
).head(50)

# Sort products by net sales
top_discount_revenue_products = product_discount.sort_values(
    by="net_sales",
    ascending=False
).head(50)

# Save the analysis files
overall_metrics.to_csv(
    r"D:\Ecommerce_Customer_Intelligence\01_Raw_Data\discount_overall_metrics.csv",
    index=False
)

discount_analysis.to_csv(
    r"D:\Ecommerce_Customer_Intelligence\01_Raw_Data\discount_range_analysis.csv",
    index=False
)

category_discount.to_csv(
    r"D:\Ecommerce_Customer_Intelligence\01_Raw_Data\category_discount_analysis.csv",
    index=False
)

high_discount_products.to_csv(
    r"D:\Ecommerce_Customer_Intelligence\01_Raw_Data\high_discount_products.csv",
    index=False
)

top_discount_revenue_products.to_csv(
    r"D:\Ecommerce_Customer_Intelligence\01_Raw_Data\top_discount_revenue_products.csv",
    index=False
)

# Display the results
print("\nOverall Discount Metrics:")
print(overall_metrics)

print("\nDiscount Range Analysis:")
print(discount_analysis)

print("\nTop High-Discount Products:")
print(
    high_discount_products[
        [
            "product_id",
            "product_name",
            "category",
            "average_discount",
            "net_sales"
        ]
    ].head(10)
)

print("\nTop Revenue Products:")
print(
    top_discount_revenue_products[
        [
            "product_id",
            "product_name",
            "category",
            "average_discount",
            "net_sales"
        ]
    ].head(10)
)

print("\nAnalysis completed successfully.")