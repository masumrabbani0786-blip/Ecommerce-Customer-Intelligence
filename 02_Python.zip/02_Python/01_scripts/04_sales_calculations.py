import pandas as pd

# Load date-cleaned dataset
file_path = r"D:\Ecommerce_Customer_Intelligence\01_Raw_Data\ecommerce_data_date_cleaned.csv"

df = pd.read_csv(file_path, encoding="utf-8-sig")

print("=" * 60)
print("SALES CALCULATION & VALIDATION")
print("=" * 60)

# Convert numerical columns
df["quantity"] = pd.to_numeric(df["quantity"], errors="coerce")
df["unit_price"] = pd.to_numeric(df["unit_price"], errors="coerce")
df["discount_percentage"] = pd.to_numeric(
    df["discount_percentage"],
    errors="coerce"
)

# Check missing numerical values
print("\nMissing values:")
print(df[[
    "quantity",
    "unit_price",
    "discount_percentage"
]].isnull().sum())

# Calculate Gross Sales
df["gross_sales"] = df["quantity"] * df["unit_price"]

# Calculate Discount Amount
df["discount_amount"] = (
    df["gross_sales"] * df["discount_percentage"] / 100
)

# Calculate Net Sales
df["net_sales"] = df["gross_sales"] - df["discount_amount"]

# Round monetary values
df["gross_sales"] = df["gross_sales"].round(2)
df["discount_amount"] = df["discount_amount"].round(2)
df["net_sales"] = df["net_sales"].round(2)

# Validation
print("\nNegative Quantity:", (df["quantity"] < 0).sum())
print("Zero Quantity:", (df["quantity"] == 0).sum())

print("\nNegative Unit Price:", (df["unit_price"] < 0).sum())

print("\nDiscount below 0%:",
      (df["discount_percentage"] < 0).sum())

print("Discount above 100%:",
      (df["discount_percentage"] > 100).sum())

# Sales summary
print("\nSALES SUMMARY")
print("Total Gross Sales:", df["gross_sales"].sum().round(2))
print("Total Discount:", df["discount_amount"].sum().round(2))
print("Total Net Sales:", df["net_sales"].sum().round(2))

# Save
output_path = r"D:\Ecommerce_Customer_Intelligence\01_Raw_Data\ecommerce_data_sales_cleaned.csv"

df.to_csv(
    output_path,
    index=False,
    encoding="utf-8-sig"
)

print("\nSales-cleaned dataset saved successfully.")
print("Rows:", len(df))
print("Columns:", len(df.columns))