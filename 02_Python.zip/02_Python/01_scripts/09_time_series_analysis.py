import pandas as pd

# Load sales-cleaned dataset
file_path = r"D:\Ecommerce_Customer_Intelligence\01_Raw_Data\ecommerce_data_sales_cleaned.csv"

df = pd.read_csv(file_path, encoding="utf-8-sig")

print("=" * 70)
print("TIME-SERIES & SALES TREND ANALYSIS")
print("=" * 70)

# Convert date
df["order_date"] = pd.to_datetime(
    df["order_date"],
    errors="coerce"
)

# Create Year and Month
df["year"] = df["order_date"].dt.year
df["month"] = df["order_date"].dt.month

# Create Year-Month
df["year_month"] = df["order_date"].dt.to_period("M").astype(str)

# --------------------------------------------------
# 1. MONTHLY SALES ANALYSIS
# --------------------------------------------------

monthly_sales = df.groupby("year_month").agg(
    orders=("order_id", "nunique"),
    quantity_sold=("quantity", "sum"),
    gross_sales=("gross_sales", "sum"),
    discount_amount=("discount_amount", "sum"),
    net_sales=("net_sales", "sum")
).reset_index()

# Average Order Value
monthly_sales["average_order_value"] = (
    monthly_sales["net_sales"] /
    monthly_sales["orders"]
)

# Month-over-Month Growth
monthly_sales["mom_growth_percentage"] = (
    monthly_sales["net_sales"]
    .pct_change() * 100
)

monthly_sales = monthly_sales.round(2)

print("\nMONTHLY SALES PERFORMANCE")
print(monthly_sales)

# --------------------------------------------------
# 2. YEARLY PERFORMANCE
# --------------------------------------------------

yearly_sales = df.groupby("year").agg(
    orders=("order_id", "nunique"),
    quantity_sold=("quantity", "sum"),
    gross_sales=("gross_sales", "sum"),
    discount_amount=("discount_amount", "sum"),
    net_sales=("net_sales", "sum")
).reset_index()

yearly_sales["average_order_value"] = (
    yearly_sales["net_sales"] /
    yearly_sales["orders"]
)

yearly_sales = yearly_sales.round(2)

print("\nYEARLY PERFORMANCE")
print(yearly_sales)

# --------------------------------------------------
# 3. BEST MONTH
# --------------------------------------------------

best_month = monthly_sales.loc[
    monthly_sales["net_sales"].idxmax()
]

print("\nBEST MONTH BY NET SALES")
print(best_month)

# --------------------------------------------------
# 4. WORST MONTH
# --------------------------------------------------

worst_month = monthly_sales.loc[
    monthly_sales["net_sales"].idxmin()
]

print("\nLOWEST MONTH BY NET SALES")
print(worst_month)

# --------------------------------------------------
# 5. SAVE RESULTS
# --------------------------------------------------

monthly_path = r"D:\Ecommerce_Customer_Intelligence\01_Raw_Data\monthly_sales_analysis.csv"

yearly_path = r"D:\Ecommerce_Customer_Intelligence\01_Raw_Data\yearly_sales_analysis.csv"

monthly_sales.to_csv(
    monthly_path,
    index=False,
    encoding="utf-8-sig"
)

yearly_sales.to_csv(
    yearly_path,
    index=False,
    encoding="utf-8-sig"
)

print("\nTime-series analysis files saved successfully.")