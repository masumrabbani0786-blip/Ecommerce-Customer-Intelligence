import pandas as pd

# Load the cleaned sales data
file_path = r"D:\Ecommerce_Customer_Intelligence\01_Raw_Data\ecommerce_data_sales_cleaned.csv"

df = pd.read_csv(file_path, encoding="utf-8-sig")

# Convert order date into datetime format
df["order_date"] = pd.to_datetime(df["order_date"])

# Create customer-level purchase metrics
customer_behavior = (
    df.groupby("customer_id")
    .agg(
        first_order_date=("order_date", "min"),
        last_order_date=("order_date", "max"),
        total_orders=("order_id", "nunique"),
        total_items=("quantity", "sum"),
        total_revenue=("net_sales", "sum"),
        average_order_value=("net_sales", "mean")
    )
    .reset_index()
)

# Calculate the number of days between first and last purchase
customer_behavior["customer_lifetime_days"] = (
    customer_behavior["last_order_date"]
    - customer_behavior["first_order_date"]
).dt.days

# Calculate purchase frequency
customer_behavior["purchase_frequency"] = (
    customer_behavior["total_orders"]
    / (customer_behavior["customer_lifetime_days"] + 1)
)

customer_behavior["purchase_frequency"] = (
    customer_behavior["purchase_frequency"].round(4)
)

# Classify customers based on their number of orders
customer_behavior["customer_type"] = customer_behavior["total_orders"].apply(
    lambda x: "One-Time Customer" if x == 1 else "Repeat Customer"
)

# Create revenue-based customer segments
customer_behavior["value_segment"] = pd.qcut(
    customer_behavior["total_revenue"],
    q=4,
    labels=[
        "Low Value",
        "Medium Value",
        "High Value",
        "Very High Value"
    ],
    duplicates="drop"
)

# Sort customers by total revenue
customer_behavior = customer_behavior.sort_values(
    by="total_revenue",
    ascending=False
)

# Save the customer-level analysis
output_path = r"D:\Ecommerce_Customer_Intelligence\01_Raw_Data\customer_behavior_analysis.csv"

customer_behavior.to_csv(
    output_path,
    index=False
)

# Create a summary of customer types
customer_type_summary = (
    customer_behavior
    .groupby("customer_type")
    .agg(
        customers=("customer_id", "nunique"),
        total_revenue=("total_revenue", "sum"),
        average_revenue=("total_revenue", "mean"),
        average_orders=("total_orders", "mean")
    )
    .reset_index()
)

customer_type_summary["revenue_percentage"] = (
    customer_type_summary["total_revenue"]
    / customer_type_summary["total_revenue"].sum()
) * 100

customer_type_summary["revenue_percentage"] = (
    customer_type_summary["revenue_percentage"].round(2)
)

# Save customer type summary
customer_type_summary.to_csv(
    r"D:\Ecommerce_Customer_Intelligence\01_Raw_Data\customer_type_summary.csv",
    index=False
)

# Create a summary of customer value segments
value_segment_summary = (
    customer_behavior
    .groupby("value_segment", observed=True)
    .agg(
        customers=("customer_id", "nunique"),
        total_revenue=("total_revenue", "sum"),
        average_revenue=("total_revenue", "mean"),
        average_orders=("total_orders", "mean")
    )
    .reset_index()
)

value_segment_summary["revenue_percentage"] = (
    value_segment_summary["total_revenue"]
    / value_segment_summary["total_revenue"].sum()
) * 100

value_segment_summary["revenue_percentage"] = (
    value_segment_summary["revenue_percentage"].round(2)
)

# Save value segment summary
value_segment_summary.to_csv(
    r"D:\Ecommerce_Customer_Intelligence\01_Raw_Data\customer_value_summary.csv",
    index=False
)

# Display the main results
print("\nCustomer Behavior:")
print(customer_behavior.head(10))

print("\nCustomer Type Summary:")
print(customer_type_summary)

print("\nCustomer Value Summary:")
print(value_segment_summary)

print("\nTotal Customers:",
      customer_behavior["customer_id"].nunique())

print("\nRepeat Customer Percentage:",
      round(
          (customer_behavior["customer_type"] == "Repeat Customer").mean() * 100,
          2
      ),
      "%")

print("\nAnalysis completed successfully.")